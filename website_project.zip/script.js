// تبديل عرض الصفحات
document.getElementById("login-form").addEventListener("submit", function(event) {
    event.preventDefault();
    document.getElementById("login-page").style.display = "none";
    document.getElementById("business-registration").style.display = "block";
});

// إضافة صنف إلى الجدول
function addItem() {
    const table = document.getElementById("items-table");
    const row = table.insertRow();
    row.innerHTML = `
        <td><input type="text" value="00001"></td>
        <td><input type="text"></td>
        <td><input type="number"></td>
        <td><input type="number"></td>
        <td><input type="number"></td>
        <td><button onclick="printBarcode()">طباعة</button></td>
    `;
}

// طباعة باركود
function printBarcode() {
    alert("تم طباعة الباركود!");
}
